import React from 'react'

const ClaimRequests = () => {
  return (
    <div>
ClaimRequests
    </div>
  )
}

export default ClaimRequests
