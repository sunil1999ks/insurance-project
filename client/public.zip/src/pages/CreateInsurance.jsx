import React, { useState } from 'react';
import { Form, Button, Card } from 'react-bootstrap';
import { FiPlusCircle } from 'react-icons/fi';

const CreateInsurance = () => {
  const [formValues, setFormValues] = useState({
    name: '',
    coverageType: 'health',
    startDate: '',
    endDate: '',
    premiumAmount: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formValues); // replace with axios.post() later
  };

  return (
    <Card className="p-5 shadow-sm border-0 rounded-4">
      <div className="d-flex align-items-center mb-4">
        <FiPlusCircle size={26} className="me-2 text-danger" />
        <h4 className="mb-0">Add New Insurance</h4>
      </div>

      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-4">
          <Form.Label className="fw-semibold">Insurance Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter insurance name"
            name="name"
            value={formValues.name}
            onChange={handleChange}
            className="rounded-3 py-3 px-4 border-light shadow-sm"
            required
          />
        </Form.Group>

        <Form.Group className="mb-4">
          <Form.Label className="fw-semibold">Coverage Type</Form.Label>
          <Form.Select
            name="coverageType"
            value={formValues.coverageType}
            onChange={handleChange}
            className="rounded-3 py-3 px-4 border-light shadow-sm"
          >
            <option value="health">Health</option>
            <option value="life">Life</option>
            <option value="vehicle">Vehicle</option>
            <option value="property">Property</option>
          </Form.Select>
        </Form.Group>

        <div className="row">
          <div className="col-md-6 mb-4">
            <Form.Label className="fw-semibold">Start Date</Form.Label>
            <Form.Control
              type="date"
              name="startDate"
              value={formValues.startDate}
              onChange={handleChange}
              className="rounded-3 py-3 px-4 border-light shadow-sm"
              required
            />
          </div>

          <div className="col-md-6 mb-4">
            <Form.Label className="fw-semibold">End Date</Form.Label>
            <Form.Control
              type="date"
              name="endDate"
              value={formValues.endDate}
              onChange={handleChange}
              className="rounded-3 py-3 px-4 border-light shadow-sm"
              required
            />
          </div>
        </div>

        <Form.Group className="mb-4">
          <Form.Label className="fw-semibold">Premium Amount (₹)</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter premium amount"
            name="premiumAmount"
            value={formValues.premiumAmount}
            onChange={handleChange}
            className="rounded-3 py-3 px-4 border-light shadow-sm"
            required
          />
        </Form.Group>

        <Button type="submit" variant="danger" className="rounded-3 px-5 py-3 fw-semibold">
           Sunmit
        </Button>
      </Form>
    </Card>
  );
};

export default CreateInsurance;
