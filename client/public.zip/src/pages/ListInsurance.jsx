import React from 'react'

const ListInsurance = () => {
  return (
    <div>
      ListInsurance
    </div>
  )
}

export default ListInsurance
