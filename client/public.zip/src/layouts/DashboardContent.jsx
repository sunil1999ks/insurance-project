import React from 'react';

const DashboardHome = () => {
  return (
    <div>
      <h3>Dashboard Overview</h3>
      <p>Welcome to your insurance management dashboard.</p>
    </div>
  );
};

export default DashboardHome;
