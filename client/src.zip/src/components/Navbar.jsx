import React from 'react';
import logo from "./../images/id-main-logo.svg";
import "./Navbar.css"; // Import the CSS file we'll write below

const Navbar = () => {
  return (
    <nav className="navbar bg-white shadow-sm border-bottom sticky-top py-2">
      <div className="w-100 d-flex justify-content-between align-items-center px-4 px-md-5">

        {/* Logo */}
        <a className="navbar-brand d-flex align-items-center me-4" href="#">
          <img src={logo} alt="Logo" width="180" height="50" />
        </a>

        {/* Main Nav */}
        <ul className="nav gap-4 d-none d-lg-flex align-items-center">


          
          <li className="nav-item">
            <a className="nav-link fw-medium text-dark" href="#">Insurance</a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-medium text-dark" href="#">Advisors</a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-medium text-dark" href="#">Renew</a>
          </li>

          {/* Dropdown */}
          <li className="nav-item dropdown custom-dropdown">
            <a className="nav-link fw-medium text-dark dropdown-toggle" href="#">
              Support
            </a>
            <ul className="dropdown-menu">
              <li><a className="dropdown-item" href="#">Renew Policy</a></li>
              <li><a className="dropdown-item" href="#">Track Policy</a></li>

              {/* Submenu */}
              <li className="dropdown-submenu">
                <a className="dropdown-item dropdown-toggle" href="#">More Options</a>
                <ul className="dropdown-menu">
                  <li><a className="dropdown-item" href="#">Claim Help</a></li>
                  <li><a className="dropdown-item" href="#">Cancel Policy</a></li>
                </ul>
              </li>
            </ul>
          </li>

          <li className="nav-item">
            <a className="nav-link fw-medium text-dark" href="#">News</a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-medium text-dark" href="#">Become POSP Agent</a>
          </li>
        </ul>

        {/* Search & Login */}
        <div className="d-flex align-items-center gap-2">
          <input
            className="form-control rounded-pill px-3 border-light shadow-sm d-none d-md-block"
            type="search"
            placeholder="Search"
            aria-label="Search"
            style={{ width: '180px' }}
          />
          <button className="btn btn-primary rounded-pill px-4" type="button">
            Login
          </button>

          {/* Mobile Toggler */}
          <button
            className="navbar-toggler d-lg-none border-0"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapseMobile"
            aria-controls="navbarCollapseMobile"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
        </div>
      </div>

      {/* Mobile Collapsible Nav */}
      <div className="collapse navbar-collapse d-lg-none px-4" id="navbarCollapseMobile">
        <ul className="navbar-nav py-3 border-top">
          <li className="nav-item"><a className="nav-link fw-medium text-dark" href="#">Insurance</a></li>
          <li className="nav-item"><a className="nav-link fw-medium text-dark" href="#">Advisors</a></li>
          <li className="nav-item"><a className="nav-link fw-medium text-dark" href="#">Renew</a></li>
          <li className="nav-item"><a className="nav-link fw-medium text-dark" href="#">Support</a></li>
          <li className="nav-item"><a className="nav-link fw-medium text-dark" href="#">News</a></li>
          <li className="nav-item"><a className="nav-link fw-medium text-dark" href="#">Become POSP Agent</a></li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
